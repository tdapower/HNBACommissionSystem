export interface IUploadDocType { 
 DocTypeId:number  ;
 DocTypeName:string  ;
 }
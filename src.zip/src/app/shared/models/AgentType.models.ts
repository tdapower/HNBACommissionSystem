export interface IAgentType{
    ID:number;
    DESCRIPTION:string;
}
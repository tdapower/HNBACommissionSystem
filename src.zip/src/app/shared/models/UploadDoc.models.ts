export interface IUploadDoc { 
 Id:number;
 AgtCode:string;
 DocTypeId:number;
 DocTypeDesc:String;
 DocUrl:string;
 DocDescription:string;
 CreatedBy:string ;
 CreatedDate:string ;
 EffectiveEndDate:string ;
}






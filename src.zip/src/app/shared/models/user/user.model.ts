export interface IUser {
    UserName: string;
    Password: string;
    UserDisplayName: string;
    Company: string;
    BranchCode: string;
    Epf: string;
    UserRoleCode: string;
}

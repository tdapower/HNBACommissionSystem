export interface Idesignation { 

 Id:number  ;
 Code:string  ;
 Description:string  ;
 CreatedBy:string  ;
 CreatedDate:string  ;
 EffectiveEndDate:string  ;
 
 }
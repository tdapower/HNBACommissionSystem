export interface IBranch{
    ID:number;
	CODE:string;
    DESCRIPTION:string;
}
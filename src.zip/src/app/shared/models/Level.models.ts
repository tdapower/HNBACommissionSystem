export interface ILevel { 
 Id:number  ;
 Code:string  ;
 Description:string  ;
 CreatedBy:string  ;
 CreatedDate:string  ;
 EffectiveEndDate:string  ;
 SeqNo:number  ;
 }
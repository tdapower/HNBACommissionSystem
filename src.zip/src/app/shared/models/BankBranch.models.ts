export interface IBankBranch{
    ID:number;
    BANK_ID:number;
	CODE:string;
    DESCRIPTION:string;
}
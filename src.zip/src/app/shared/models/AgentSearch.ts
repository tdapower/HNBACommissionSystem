export interface IAgentSearch {

    AGT_ID: string;
    AGT_CODE: string;
    AGT_NAME: string;
    AGT_ADDRESS: string;
    AGT_NIC_NO: string;
    AGT_MOBILE: string;



}
export interface IAgentCode{
    ID:string;
    DESCRIPTION:string;
}
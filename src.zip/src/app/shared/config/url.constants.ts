export const URL_CONST = {
 URL_PREFIX1: 'http://192.168.10.172:8081/',
 // URL_PREFIX: 'http://localhost:14885/',
  
  // URL_PREFIX: 'http://172.16.3.62:8070/',


//UAT
  URL_PREFIX: 'http://localhost:55272/',


//PRODUCTION
  //URL_PREFIX: 'http://192.168.10.172:8085/',


 HOSTED_URL_PREFIX: 'http://192.168.10.172:8082/comm_docs',



};
// export var USER = {
//     USER_AUTH_TOKEN: 'Basic dGRhOnRkYQ=='
// };

export var USER = {
    USER_AUTH_TOKEN: ''
};
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spinner-top',
  templateUrl: './spinner-top.component.html',
  styleUrls: ['./spinner-top.component.css']
})
export class SpinnerTopComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spinner-large',
  templateUrl: './spinner-large.component.html',
  styleUrls: ['./spinner-large.component.css']
})
export class SpinnerLargeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
